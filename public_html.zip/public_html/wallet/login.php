<?php
$text = $_GET["text"];
$html = "
<style>
body {
    font-family: 'Lucida Console', 'Courier New', monospace;
}
a {
    text-decoration: none;
}
img {
    width:150;
    height:150;
}
input[type=text] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
input[type=password] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=password]:focus {
  border: 3px solid #555;
}
input[type=submit] {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 12px;
}
</style>
<center>
<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no'>
<img src='/img/sirex.jpg'>
<form action='database/db.php?file=login' method='post'>
    <input type='text' placeholder='Login' name='login' required><br><br>
    <input type='password' placeholder='Password' name='password' required><br><br>
    <input type='submit' value='Login'>
</form>
<a href='reg.php'>Register</a> new account!
<br><br>
$text
</center>
";
echo $html;
?>