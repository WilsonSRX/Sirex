<?php
$file = $_GET["file"];
$login = $_POST["login"];
$password = $_POST["password"];
if (file_exists("$login")) {
    header("Location: $login/proverka.php?file=$file&password=$password");
} else {
    header("Location: /wallet/$file.php?text=Account does not exist!");
}