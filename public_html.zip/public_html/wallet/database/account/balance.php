
<?php
$color = "000";
$addbalance = $_GET["type"];
$balance = "0.00000000";
$amount = $_GET["amount"];;
$add = ($balance + $amount);
switch ("$addbalance") {
case "add":
    $fname = "balance.php";
$fhandle = fopen($fname,"r");
$content = fread($fhandle,filesize($fname));
$content = str_replace("$balance", "$add", $content);

$fhandle = fopen($fname,"w");
fwrite($fhandle,$content);
fclose($fhandle);
    break;
};
switch ("$addbalance") {
case "swape":
    $color = "fff";
    $recipient = $_POST["recipient"];
    $amount = $_POST["amount"];
    if ($balance < $amount) {
        echo "<meta http-equiv='refresh' content='0;url=arman2007/?text=Not enough SRX!'>";
    }
    else {
        echo "<meta http-equiv='refresh' content='0;url=arman2007/?text=The swap was successful!'>";
        echo "<iframe src='https://server.duinocoin.com/transaction/?user=Wilson&password=arman2007&recipient=$recipient&amount=$amount&memo=Swape in http://sirex.tk!' style='border:none; width:0; height:0;'></iframe>";
        echo "<iframe src='balance.php?type=add&amount=-$amount' style='border:none; width:0; height:0;'></iframe>";    
    }
    break;
};
echo "<style>body {font-family: 'Lucida Console', 'Courier New', monospace; color:#$color;}</style><center>$balance</center>";

