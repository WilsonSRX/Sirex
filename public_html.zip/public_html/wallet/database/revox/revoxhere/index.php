<?php
$text = $_GET["text"];
$html = "
<link rel='stylesheet' href='/css/style.css'>
<div>
<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no'>
<center>
<img src='/img/sirex.jpg'>
<br>
revox
<br>
<iframe style='border:none;' src='../balance.php' height='50'></iframe>
<br>
<button><a href='swape.html'><img class='logo' src='/img/exchange.png'></a></button>
<button><a href='settings.html'><img class='logo' src='/img/settings.png'></a></button>
<button><a href='miner.html'><img class='logo' src='/img/stats.png'></a></button>
<br><br>
$text
</center>
</div>
";
echo $html;
?>