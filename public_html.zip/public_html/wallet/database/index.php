<?php
header("Location: /wallet");
?>