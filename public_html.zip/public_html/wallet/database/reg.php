<?php
$text = '$text';
$file = $_GET["file"];
$login = $_POST["login"];
$password = $_POST["password"];
$file2 = "account/balance.php";
$newfile = "$login/balance.php";
$file3 = "account/arman2007/index.php";
$newfile2 = "$login/$password/index.php";
if (file_exists("$login")) {
    header("Location: /wallet/$file.php?text=The account is already taken!");
} else {
mkdir("$login", 0700);
mkdir("$login/$password", 0700);
$index = '<?php
$text = $_GET["text"];
$html = "
<link rel="stylesheet" href="/css/style.css">
<div>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no">
<center>
<img src="/img/sirex.jpg">
<br>
Wilson
<br>
<iframe style="border:none;" src="../balance.php" height="50"></iframe>
<br>
<button><a href="swape.html"><img class="logo" src="/img/exchange.png"></a></button>
<button><a href="settings.html"><img class="logo" src="/img/settings.png"></a></button>
<button><a href="miner.html"><img class="logo" src="/img/stats.png"></a></button>
<br><br>
$text
</center>
</div>
";
echo $html;
?>';
$proverka = '<?php
$file = $_GET["file"];
$password = $_GET["password"];
if (file_exists("$password")) {
    header("Location: $password");
} else {
    header("Location: /wallet/$file.php?text=Invalid password!");
}';
$settingshtml = '<style>
    body {
    font-family: "Lucida Console", "Courier New", monospace;
}
a {
    text-decoration: none;
}
img {
    width:150;
    height:150;
}
input[type=password] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=password]:focus {
  border: 3px solid #555;
}
input[type=number] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=number]:focus {
  border: 3px solid #555;
}
input[type=submit] {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 12px;
}
</style>
<center>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no">
<img src="/img/sirex.jpg">
<form action="settings.php" method="post">
<input type="password" name="oldpassword" placeholder="Old password" required><br><br>
<input type="password" name="newpassword" placeholder="New password" required><br><br>
<input type="submit" value="Change">
</form>
<a href="index.php">Go</a> to dashboard!
</center>';
$settingsphp = '<?php
$old = $_POST["oldpassword"];
$new = $_POST["newpassword"];

rename ("../$old", "../$new");
    $fname = "../balance.php";
$fhandle = fopen($fname,"r");
$content = fread($fhandle,filesize($fname));
$content = str_replace("$old", "$new", $content);

$fhandle = fopen($fname,"w");
fwrite($fhandle,$content);
fclose($fhandle);
header("Location: ../$new/index.php?text=Password changed!");
?>';
$swape = '<style>
    input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
     display: none; 
    -webkit-appearance: none;
    margin: 0;
}
body {
    font-family: "Lucida Console", "Courier New", monospace;
}
a {
    text-decoration: none;
}
img {
    width:150;
    height:150;
}
input[type=text] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus {
  border: 3px solid #555;
}
input[type=number] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=number]:focus {
  border: 3px solid #555;
}
input[type=submit] {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 12px;
}
</style>
<center>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no">
<img src="/img/sirex.jpg">
<form action="../balance.php?type=swape" method="post">
<input type="text" name="recipient" placeholder="Recipient in DUCO" required><br><br>
<input type="number" name="amount" placeholder="Amount" min="0.00001000" value="0.00001000" required><br><br>
<input type="submit" value="Swape">
</form>
<a href="index.php">Go</a> to dashboard!
</center>';
$index1 = '<link rel="stylesheet" href="/css/style.css">
<div>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no">
<center>
<img src="/img/sirex.jpg">
<br>
Wilson
<br>
<iframe style="border:none;" src="../balance.php" height="50"></iframe>
<br>
<button><a href="swape.html"><img class="logo" src="/img/exchange.png"></a></button>
<button><a href="settings.html"><img class="logo" src="/img/settings.png"></a></button>
<button><a href="miner.html"><img class="logo" src="/img/stats.png"></a></button>
<br><br>
$text
</center>
</div>';
$index2 = "<link rel='stylesheet' href='/css/style.css'>
<div>
<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no'>
<center>
<img src='/img/sirex.jpg'>
<br>
$login
<br>
<iframe style='border:none;' src='../balance.php' height='50'></iframe>
<br>
<button><a href='swape.html'><img class='logo' src='/img/exchange.png'></a></button>
<button><a href='settings.html'><img class='logo' src='/img/settings.png'></a></button>
<button><a href='miner.html'><img class='logo' src='/img/stats.png'></a></button>
<br><br>
$text
</center>
</div>";
copy($file2, $newfile);
    $fname = "$login/balance.php";
$fhandle = fopen($fname,"r");
$content = fread($fhandle,filesize($fname));
$content = str_replace("arman2007", "$password", $content);

$fhandle = fopen($fname,"w");
fwrite($fhandle,$content);
fclose($fhandle);

$fp = fopen("$login/$password/index.php", "w");
$fpb = fopen("$login/proverka.php", "w");
$fps = fopen("$login/$password/settings.html", "w");
$fpsp = fopen("$login/$password/settings.php", "w");
$fpsw = fopen("$login/$password/swape.html", "w");

fwrite($fpb, $proverka);
fwrite($fpsw, $swape);
fwrite($fps, $settingshtml);
fwrite($fpsp, $settingsphp);
fwrite($fp, $index);
fwrite($db, $dbt);
    $fname2 = "$login/$password/index.php";
$fhandle2 = fopen($fname2,"r");
$content2 = fread($fhandle2,filesize($fname2));
$content2 = str_replace("$index1", "$index2", $content2);

$fhandle2 = fopen($fname2,"w");
fwrite($fhandle2,$content2);
fclose($fhandle2);
 
fclose($fp);
fclose($fps);
fclose($fpsp);
fclose($fpb);
fclose($fpw);
$fhandle2 = fopen($fname2,"w");
fwrite($fhandle2,$content2);
fclose($fhandle2);
$url = "$login/$password";
header("Location: " .$url);
}
?>