<?php
$file = $_GET["file"];
$password = $_GET["password"];
if (file_exists("$password")) {
    header("Location: $password");
} else {
    header("Location: /wallet/$file.php?text=Invalid password!");
}