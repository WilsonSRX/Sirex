<?php
$html = "
<style>
body {
    font-family: 'Lucida Console', 'Courier New', monospace;
    font-size:20;
}
</style>
<meta http-equiv='refresh' content='5;url=../balance.php?type=add&amount=0.00000176'>
<center>
SMiner
<br>
<br>
<div id='khs'></div>
Kh/s</center>

<script>
document.getElementById('khs').innerHTML =
Math.floor(Math.random() * 100) + 50;
</script>
";
echo $html;
?>