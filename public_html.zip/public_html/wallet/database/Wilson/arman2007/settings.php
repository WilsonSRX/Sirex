<?php
$old = $_POST["oldpassword"];
$new = $_POST["newpassword"];

rename ("../$old", "../$new");
    $fname = "../balance.php";
$fhandle = fopen($fname,"r");
$content = fread($fhandle,filesize($fname));
$content = str_replace("$old", "$new", $content);

$fhandle = fopen($fname,"w");
fwrite($fhandle,$content);
fclose($fhandle);
header("Location: ../$new/index.php?text=Password changed!");
?>